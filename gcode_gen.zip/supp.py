import math
import os
import numpy as np
from params import *
from func import *

def rad(d):
    tot_len = 0
    r = d / 2 - dxy / 2 # radius of the printed circle
    s = 2 * math.pi * r / dxy   # circumference of the circle
    n = math.floor(math.log(s, 2)) # 2 ** n lines will be used to print the circle

    # define first 4 lines of the circle. [normalized angle, start_x, start_y, end_x, end_y]
    lines = np.array([[0, r, 0, 0, 0], [0.25, 0, r, 0, 0],
     [0.5, -r, 0, 0, 0], [0.75, 0, -r, 0, 0]])

    # calculate all the next lines
    for i in range(2, n + 1):
        a = 2 * math.pi / (2 ** i) # increment of angle
        r0 = dxy * (1 / 2 + 0.5 / math.sin(a / 2))
        for j in range(2 ** i):
            ap = a * (j + 0.5)  # angle of current line
            temp = np.array([ap * 0.5 / math.pi, math.cos(ap) * r, math.sin(ap) * r, math.cos(ap) * r0, math.sin(ap) * r0])
            temp = np.reshape(temp, (1, 5))
            lines = np.append(lines, temp, axis = 0)

    lines = lines[lines[:,0].argsort()] # sort by angle
    return lines
