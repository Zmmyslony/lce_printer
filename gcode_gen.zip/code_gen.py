from params import *
from func import *

# Staircase film with parallel orinetation
if 1:
    init(0, 2, T = 90)
    for i in range(10):
        film(20 - 2 * i, 4, 0.16)
    set_abs(z = 0)
    close("staircase", 25, -2, 0, s = 1, T = 90)

# Film with parallel orientation
if 1:
    init(0, 20)
    film(30, 5, 3)
    close("parallel", 0, -20, 20, s = 1)

# Single concentric circles layer
if 1:
    init(-20, 15)
    conc(10)
    close("concentric", 0, -5, 5, s = 1)

# 4 layers of archimedes spiral
if 1:
    init(-20, 10)
    archim(15)
    rise()
    archim(15)
    rise()
    archim(15)
    rise()
    archim(15)
    close("archimedes", 5, -8, 5, T = 0, s = 1)

# 4 radial films with varying number of layers
if 1:
    init(0, 10)
    radial(15)

    move(x = 20)
    radial(15)
    rise()
    radial(15)

    move(y = 20, z = -dz)
    radial(15)
    rise()
    radial(15)
    rise()
    radial(15)

    move(x = -20, z = -2 * dz)
    radial(15)
    rise()
    radial(15)
    rise()
    radial(15)
    rise()
    radial(15)

    close("radial_quad", 0, 10, 20, s = 1)

# Radinoid
if 1:
    init(0, 20)
    archim(20)
    rise()
    radial(20)
    close("radinoid", 0, -20, 20, s = 1)

# Test from 27 th of Feb 2020; checking double layered combinations of circular films
if 1:
    filename_test_1 = "test_20_02_27"
    init(0, -15)
    conc(20)
    rise()
    conc(20)

    move(x = 30)
    archim(20)
    rise()
    archim(20)

    move(y = 30)
    radial(20)
    rise()
    radial(20)

    move(x = -30)
    archim(20)
    rise()
    set_abs(x = 0, y = 30)
    radial(20)
    close("test_20_02_27", -20, 0, 20, s = 1)
